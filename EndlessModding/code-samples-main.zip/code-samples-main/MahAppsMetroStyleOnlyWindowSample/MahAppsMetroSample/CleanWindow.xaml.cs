﻿using MahApps.Metro.Controls;

namespace MahAppsMetroSample
{
    /// <summary>
    /// Interaction logic for CleanWindow.xaml
    /// </summary>
    public partial class CleanWindow : MetroWindow
    {
        public CleanWindow()
        {
            InitializeComponent();
        }
    }
}
