# HamburgerMenu Samples

## HamburgerMenuApp.V1

## HamburgerMenuApp.V2

## HamburgerMenuApp.V3

## HamburgerMenuApp.V4

HamburgerMenu sample with own ViewModel collection instead using the HamburgerMenuItem and HamburgerMenuItemCollection.

![](mahapps_hamburger_viewmodelcollection.gif)
