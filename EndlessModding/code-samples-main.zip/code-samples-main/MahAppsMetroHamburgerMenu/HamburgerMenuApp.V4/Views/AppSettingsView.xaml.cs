﻿using System.Windows.Controls;

namespace HamburgerMenuApp.V4.Views
{
    /// <summary>
    /// Interaction logic for AboutView.xaml
    /// </summary>
    public partial class AppSettingsView : UserControl
    {
        public AppSettingsView()
        {
            InitializeComponent();
        }
    }
}
