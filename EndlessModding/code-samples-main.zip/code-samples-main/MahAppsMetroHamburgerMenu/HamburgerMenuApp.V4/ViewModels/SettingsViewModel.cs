﻿using HamburgerMenuApp.Core.MVVM;

namespace HamburgerMenuApp.V4.ViewModels
{
    public class SettingsViewModel : MenuItemViewModel
    {
        public SettingsViewModel(MainViewModel mainViewModel) : base(mainViewModel)
        {
        }
    }
}