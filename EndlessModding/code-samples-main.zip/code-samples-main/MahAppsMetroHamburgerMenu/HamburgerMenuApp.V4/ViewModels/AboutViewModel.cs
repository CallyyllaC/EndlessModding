﻿using HamburgerMenuApp.Core.MVVM;

namespace HamburgerMenuApp.V4.ViewModels
{
    public class AboutViewModel : MenuItemViewModel
    {
        public AboutViewModel(MainViewModel mainViewModel) : base(mainViewModel)
        {
        }
    }
}