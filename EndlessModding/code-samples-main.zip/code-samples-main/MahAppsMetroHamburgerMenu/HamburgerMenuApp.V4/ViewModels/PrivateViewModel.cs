﻿using HamburgerMenuApp.Core.MVVM;

namespace HamburgerMenuApp.V4.ViewModels
{
    public class PrivateViewModel : MenuItemViewModel
    {
        public PrivateViewModel(MainViewModel mainViewModel) : base(mainViewModel)
        {
        }
    }
}