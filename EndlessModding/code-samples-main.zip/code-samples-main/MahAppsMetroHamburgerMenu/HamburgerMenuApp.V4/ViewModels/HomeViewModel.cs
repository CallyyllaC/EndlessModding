﻿using HamburgerMenuApp.Core.MVVM;

namespace HamburgerMenuApp.V4.ViewModels
{
    public class HomeViewModel : MenuItemViewModel
    {
        public HomeViewModel(MainViewModel mainViewModel) : base(mainViewModel)
        {
        }
    }
}